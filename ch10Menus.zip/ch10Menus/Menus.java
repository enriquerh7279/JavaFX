package ch10Menus;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Menus extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        MenuBar menuBar = new MenuBar();
        Menu menuGame = new Menu("_Game");
        Menu menuSettings = new Menu("_Settings");
        Menu menuDisplay = new Menu("_Display");
        menuBar.getMenus().addAll(menuGame, menuSettings, menuDisplay);

        MenuItem menuItemNewGame = new MenuItem("_New Game");
        MenuItem menuItemLoadGame = new MenuItem("_Load Game");
        menuGame.getItems().addAll(menuItemNewGame, menuItemLoadGame);

        Menu menuDifficulty = new Menu("Difficulty");
        menuSettings.getItems().add(menuDifficulty);
        RadioMenuItem menuItemEasy = new RadioMenuItem("_Easy");
        RadioMenuItem menuItemMedium = new RadioMenuItem("_Medium");
        RadioMenuItem menuItemHard = new RadioMenuItem("_Hard");

        ToggleGroup groupDifficulty = new ToggleGroup();
        menuItemEasy.setToggleGroup(groupDifficulty);
        menuItemMedium.setToggleGroup(groupDifficulty);
        menuItemHard.setToggleGroup(groupDifficulty);

        menuDifficulty.getItems().addAll(menuItemEasy, menuItemMedium, menuItemHard);

        Menu menuOptions = new Menu("_Options");
        CheckMenuItem menuItemName = new CheckMenuItem("_Show User Name");
        CheckMenuItem menuItemScore = new CheckMenuItem("_Show Current Score");
        CheckMenuItem menuItemHighScore = new CheckMenuItem("_Show High Score");
        menuOptions.getItems().addAll(menuItemName, menuItemScore, menuItemHighScore);
        menuDisplay.getItems().add(menuOptions);

        TextField txtName = new TextField();
        txtName.setPromptText("Player Name");
        CustomMenuItem menuItemPlayerName = new CustomMenuItem(txtName);
        menuItemPlayerName.setHideOnClick(false);
        menuOptions.getItems().add(menuItemPlayerName);

        VBox mainPane = new VBox();
        mainPane.getChildren().add(menuBar);
        mainPane.setPadding(new Insets(5));
        mainPane.setPrefSize(300, 300);

        Scene scene = new Scene(mainPane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Game Menus");
        primaryStage.show();
    }
}
